/**
 * example codes for friendship resources
 */
package twitter4j.examples.friendship;