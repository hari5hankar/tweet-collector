/**
 * example code for trends resources
 */
package twitter4j.examples.trends;