/**
 * example codes for user resources
 */
package twitter4j.examples.user;