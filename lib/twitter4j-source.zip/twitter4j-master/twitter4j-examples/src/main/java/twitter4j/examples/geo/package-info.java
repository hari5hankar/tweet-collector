/**
 * example codes for geo resources
 */
package twitter4j.examples.geo;