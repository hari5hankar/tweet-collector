/**
 * example codes for streaming API
 */
package twitter4j.examples.stream;