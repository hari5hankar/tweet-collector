/**
 * example codes for friends and followers resources
 */
package twitter4j.examples.friendsandfollowers;