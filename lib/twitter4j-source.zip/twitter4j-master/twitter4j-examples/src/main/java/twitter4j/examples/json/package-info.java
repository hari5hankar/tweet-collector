/**
 * example codes explaining getting and storing JSON
 */
package twitter4j.examples.json;