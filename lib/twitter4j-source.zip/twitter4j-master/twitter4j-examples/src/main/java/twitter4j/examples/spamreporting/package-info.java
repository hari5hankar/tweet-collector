/**
 * example codes for spam reporting resources
 */
package twitter4j.examples.spamreporting;