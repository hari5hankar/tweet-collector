/**
 * example codes for block resources
 */
package twitter4j.examples.block;