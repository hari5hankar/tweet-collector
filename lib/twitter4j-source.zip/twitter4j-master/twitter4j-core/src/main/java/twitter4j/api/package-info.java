/**
 * APIs represents Twitter API resources
 */
package twitter4j.api;