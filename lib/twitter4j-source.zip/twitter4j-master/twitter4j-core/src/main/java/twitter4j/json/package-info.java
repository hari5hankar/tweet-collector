/**
 * this package is deprecated.
 * @deprecated use {@link twitter4j.TwitterObjectFactory} instead
 */
package twitter4j.json;